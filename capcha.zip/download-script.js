import { chromium, firefox } from "playwright-core";
import { solve } from "recaptcha-solver";

async function main() {
    // Get the URL from command line arguments
    const EXAMPLE_PAGE = process.argv[2];
    if (!EXAMPLE_PAGE) {
        console.error("Please provide a URL as an argument.");
        process.exit(1);
    }

    const browser = await firefox.launch({ headless: false });
    const page = await browser.newPage();

    try {
        await page.goto(EXAMPLE_PAGE);

        console.time("solve reCAPTCHA");
        await solve(page);
        console.log("solved!");
        console.timeEnd("solve reCAPTCHA");

        // Submit the form
        await page.$eval("#F1", form => form.submit());

        // Wait for navigation after form submission
        await page.waitForNavigation({ waitUntil: 'networkidle' });

        // Extract the download URL (adjust the selector based on the actual page)
        const downloadUrl = await page.evaluate(() => {
            // Replace this with the actual logic to get the download URL
            const linkElement = document.querySelector('a.button[download]'); // Update selector as needed
            return linkElement ? linkElement.href : null;
        });

        if (downloadUrl) {
            console.log(downloadUrl); // Print the download URL to the console
        } else {
            console.log("Download URL not found.");
        }

    } catch (error) {
        console.error("An error occurred:", error);
    } finally {
        await browser.close();
        process.exit(0);
    }
}

main();